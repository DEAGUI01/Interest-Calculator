﻿//Daniel Aguilar            Grading ID: K7209           CIS 199-01          Program 3           11/09/2022
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void CalculateInterestButton_Click(object sender, EventArgs e)
        {
            //paralel arrays for credit scores and interest rates
        
            int[] creditScores = new int[5] { 579, 669, 739, 799, 850 };
            double[] loanInterests = new double[5] { 0.0814, 0.07373, 0.07063, 0.06149, 0.059 };
            string[] creditRatings = new string[5] { "Poor", "Fair", "Good", "Very Good", "Excellent" };
            string creditRating = "";

            //paralel arrays for loan types and base rate
            string[] loanTypes = new string[3] { "Home", "Auto", "Unsecured" };
            double[] baseRates = new double[3] { 1, 1.3, 2.0 };
            double baseRate = 0;

            //paralel arrays for loan Amounts and down Payment rates
            int[] loanAmounts = new int[5] { 499, 1999, 9999, 99999, 500000 };
            double[] downPaymentRate = new double[5] { 0, 0.1, 0.15, 0.1, 0.05 };
      

            string loanAmountInput = LoanAmountInputBox.Text;       //loan amount input string
            string creditScoreInput = CreditScoreInputBox.Text;     //credit score input string
            string loanType = "";           //string to store loan type value
            double loanInterest = 0;        //variable to store loan interest
            int creditScore = 0;            //credit score variable
            int loanAmount = 0;             //loan amount variable
            double totalLoanInterest = 0;           //total interest to be output to user
            double downPayment = 0;                 //downpayment to be output to user
            if (int.TryParse(creditScoreInput, out creditScore) && int.TryParse(loanAmountInput, out loanAmount) && LoanTypeComboBox.SelectedIndex != -1)       //validate input
            {
                if ((creditScore >= 300 && creditScore <= 850) && (loanAmount > 0 && loanAmount <= 500000))         //validate credit score and loan amount are within range
                {
                    //search loan amount and assign a down payment
                    for (int index = 0; index < loanAmounts.Length; index++)
                    {
                        if(loanAmount <= loanAmounts[index])
                        {
                            downPayment = downPaymentRate[index] * loanAmount;
                            break;
                        }
                    }

            
                    //search for credit score and assign interest rate and credit rating
                    for (int index = 0; index < creditScores.Length; index++)
                    {
                        if (creditScore <= creditScores[index])
                        {
                            loanInterest = loanInterests[index];
                            creditRating = creditRatings[index];
                            break;
                        }

                    }
                    loanType = LoanTypeComboBox.Text;
                    //search for loan types and assign a base rate
                    for (int index = 0; index < loanTypes.Length; index++)
                    {
                        if(loanType == loanTypes[index])
                        {
                            baseRate = baseRates[index];
                            break;
                        }
                    }
            
                    //calculate total interest to be output
                    totalLoanInterest = baseRate * loanInterest;
                    //output loan interest, credit rating, and down payment
                    LoanInterestOutputLabel.Text = $"{totalLoanInterest:P}";
                    CreditRatingOutputLabel.Text = $"{creditRating}";
                    DownPaymentOutputLabel.Text = $"{downPayment:C}";

                }
                else
                {
                    //lets the user know the input it out of range
                    MessageBox.Show("Loan Amount or Credit Score out of range");
                }
            }
            else
            {
                //lets the user know the input is invalid
                MessageBox.Show("Invalid input");
            }
        }
 

        private void LoanTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
