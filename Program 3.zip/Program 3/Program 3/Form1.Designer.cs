﻿
namespace Program_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LoanTypeLabel = new System.Windows.Forms.Label();
            this.CreditScoreLabel = new System.Windows.Forms.Label();
            this.LoanAmountLabel = new System.Windows.Forms.Label();
            this.CalculateInterestButton = new System.Windows.Forms.Button();
            this.CreditScoreInputBox = new System.Windows.Forms.TextBox();
            this.LoanAmountInputBox = new System.Windows.Forms.TextBox();
            this.LoanTypeComboBox = new System.Windows.Forms.ComboBox();
            this.LoanInterestLabel = new System.Windows.Forms.Label();
            this.CreditRatingLabel = new System.Windows.Forms.Label();
            this.DownPaymentLabel = new System.Windows.Forms.Label();
            this.LoanInterestOutputLabel = new System.Windows.Forms.Label();
            this.CreditRatingOutputLabel = new System.Windows.Forms.Label();
            this.DownPaymentOutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LoanTypeLabel
            // 
            this.LoanTypeLabel.AutoSize = true;
            this.LoanTypeLabel.Location = new System.Drawing.Point(30, 68);
            this.LoanTypeLabel.Name = "LoanTypeLabel";
            this.LoanTypeLabel.Size = new System.Drawing.Size(76, 17);
            this.LoanTypeLabel.TabIndex = 0;
            this.LoanTypeLabel.Text = "Loan Type";
            // 
            // CreditScoreLabel
            // 
            this.CreditScoreLabel.AutoSize = true;
            this.CreditScoreLabel.Location = new System.Drawing.Point(30, 109);
            this.CreditScoreLabel.Name = "CreditScoreLabel";
            this.CreditScoreLabel.Size = new System.Drawing.Size(86, 17);
            this.CreditScoreLabel.TabIndex = 1;
            this.CreditScoreLabel.Text = "Credit Score";
            // 
            // LoanAmountLabel
            // 
            this.LoanAmountLabel.AutoSize = true;
            this.LoanAmountLabel.Location = new System.Drawing.Point(30, 153);
            this.LoanAmountLabel.Name = "LoanAmountLabel";
            this.LoanAmountLabel.Size = new System.Drawing.Size(92, 17);
            this.LoanAmountLabel.TabIndex = 2;
            this.LoanAmountLabel.Text = "Loan Amount";
            // 
            // CalculateInterestButton
            // 
            this.CalculateInterestButton.Location = new System.Drawing.Point(107, 197);
            this.CalculateInterestButton.Name = "CalculateInterestButton";
            this.CalculateInterestButton.Size = new System.Drawing.Size(163, 48);
            this.CalculateInterestButton.TabIndex = 3;
            this.CalculateInterestButton.Text = "Calculate Interest";
            this.CalculateInterestButton.UseVisualStyleBackColor = true;
            this.CalculateInterestButton.Click += new System.EventHandler(this.CalculateInterestButton_Click);
            // 
            // CreditScoreInputBox
            // 
            this.CreditScoreInputBox.Location = new System.Drawing.Point(132, 106);
            this.CreditScoreInputBox.Name = "CreditScoreInputBox";
            this.CreditScoreInputBox.Size = new System.Drawing.Size(100, 22);
            this.CreditScoreInputBox.TabIndex = 5;
            // 
            // LoanAmountInputBox
            // 
            this.LoanAmountInputBox.Location = new System.Drawing.Point(132, 148);
            this.LoanAmountInputBox.Name = "LoanAmountInputBox";
            this.LoanAmountInputBox.Size = new System.Drawing.Size(100, 22);
            this.LoanAmountInputBox.TabIndex = 6;
            // 
            // LoanTypeComboBox
            // 
            this.LoanTypeComboBox.FormattingEnabled = true;
            this.LoanTypeComboBox.Items.AddRange(new object[] {
            "Home",
            "Auto",
            "Unsecured"});
            this.LoanTypeComboBox.Location = new System.Drawing.Point(132, 65);
            this.LoanTypeComboBox.Name = "LoanTypeComboBox";
            this.LoanTypeComboBox.Size = new System.Drawing.Size(121, 24);
            this.LoanTypeComboBox.TabIndex = 7;
            this.LoanTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.LoanTypeComboBox_SelectedIndexChanged);
            // 
            // LoanInterestLabel
            // 
            this.LoanInterestLabel.AutoSize = true;
            this.LoanInterestLabel.Location = new System.Drawing.Point(30, 285);
            this.LoanInterestLabel.Name = "LoanInterestLabel";
            this.LoanInterestLabel.Size = new System.Drawing.Size(91, 17);
            this.LoanInterestLabel.TabIndex = 8;
            this.LoanInterestLabel.Text = "Loan Interest";
            // 
            // CreditRatingLabel
            // 
            this.CreditRatingLabel.AutoSize = true;
            this.CreditRatingLabel.Location = new System.Drawing.Point(30, 330);
            this.CreditRatingLabel.Name = "CreditRatingLabel";
            this.CreditRatingLabel.Size = new System.Drawing.Size(90, 17);
            this.CreditRatingLabel.TabIndex = 9;
            this.CreditRatingLabel.Text = "Credit Rating";
            this.CreditRatingLabel.Click += new System.EventHandler(this.label5_Click);
            // 
            // DownPaymentLabel
            // 
            this.DownPaymentLabel.AutoSize = true;
            this.DownPaymentLabel.Location = new System.Drawing.Point(30, 374);
            this.DownPaymentLabel.Name = "DownPaymentLabel";
            this.DownPaymentLabel.Size = new System.Drawing.Size(102, 17);
            this.DownPaymentLabel.TabIndex = 10;
            this.DownPaymentLabel.Text = "Down Payment";
            // 
            // LoanInterestOutputLabel
            // 
            this.LoanInterestOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LoanInterestOutputLabel.Location = new System.Drawing.Point(138, 285);
            this.LoanInterestOutputLabel.Name = "LoanInterestOutputLabel";
            this.LoanInterestOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.LoanInterestOutputLabel.TabIndex = 11;
            // 
            // CreditRatingOutputLabel
            // 
            this.CreditRatingOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CreditRatingOutputLabel.Location = new System.Drawing.Point(138, 329);
            this.CreditRatingOutputLabel.Name = "CreditRatingOutputLabel";
            this.CreditRatingOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.CreditRatingOutputLabel.TabIndex = 12;
            // 
            // DownPaymentOutputLabel
            // 
            this.DownPaymentOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DownPaymentOutputLabel.Location = new System.Drawing.Point(138, 373);
            this.DownPaymentOutputLabel.Name = "DownPaymentOutputLabel";
            this.DownPaymentOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.DownPaymentOutputLabel.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 450);
            this.Controls.Add(this.DownPaymentOutputLabel);
            this.Controls.Add(this.CreditRatingOutputLabel);
            this.Controls.Add(this.LoanInterestOutputLabel);
            this.Controls.Add(this.DownPaymentLabel);
            this.Controls.Add(this.CreditRatingLabel);
            this.Controls.Add(this.LoanInterestLabel);
            this.Controls.Add(this.LoanTypeComboBox);
            this.Controls.Add(this.LoanAmountInputBox);
            this.Controls.Add(this.CreditScoreInputBox);
            this.Controls.Add(this.CalculateInterestButton);
            this.Controls.Add(this.LoanAmountLabel);
            this.Controls.Add(this.CreditScoreLabel);
            this.Controls.Add(this.LoanTypeLabel);
            this.Name = "Form1";
            this.Text = "Loan Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LoanTypeLabel;
        private System.Windows.Forms.Label CreditScoreLabel;
        private System.Windows.Forms.Label LoanAmountLabel;
        private System.Windows.Forms.Button CalculateInterestButton;
        private System.Windows.Forms.TextBox CreditScoreInputBox;
        private System.Windows.Forms.TextBox LoanAmountInputBox;
        private System.Windows.Forms.ComboBox LoanTypeComboBox;
        private System.Windows.Forms.Label LoanInterestLabel;
        private System.Windows.Forms.Label CreditRatingLabel;
        private System.Windows.Forms.Label DownPaymentLabel;
        private System.Windows.Forms.Label LoanInterestOutputLabel;
        private System.Windows.Forms.Label CreditRatingOutputLabel;
        private System.Windows.Forms.Label DownPaymentOutputLabel;
    }
}

